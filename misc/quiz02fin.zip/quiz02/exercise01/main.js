function showFox() {
    document.querySelector("img").src = "images/fox.jpg";
    document.querySelector("p").textContent = "Fox";
    console.log('Change image and paragraph to fox...');
}

function showLion() {
    document.querySelector("img").src = "images/lion.jpg";
    document.querySelector("p").textContent = "Lion";

    console.log('Change image and paragraph to lion...');
}

function showTiger() {
    document.querySelector("img").src = "images/tiger.png";
    document.querySelector("p").textContent = "Tiger";

    console.log('Change image and paragraph to tiger...');
}

function showZebra() {
    document.querySelector("img").src = "images/zebra.jpg";
    document.querySelector("p").textContent = "Zerba";
    console.log('Change image and paragraph to zebra...');
}

